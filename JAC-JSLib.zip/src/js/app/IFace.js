/**
 * Created with JetBrains PhpStorm.
 * User: Jake
 */

define([],
function(){
    return (function(){
	    /**
	     * @interface
	     */
	    var IFace = {};
	    IFace.init = function($param1){};
	    IFace.destroy = function(){};
        
        
        //Return constructor
        return IFace;
    })();
});
