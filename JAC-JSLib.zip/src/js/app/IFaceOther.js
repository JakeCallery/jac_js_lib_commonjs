/**
 * Created with JetBrains PhpStorm.
 * User: Jake
 */

define([],
function(){
    return (function(){

	    var IFaceOther = {};
	    IFaceOther.doNeatStuff = function(){};
        
        
        //Return constructor
        return IFaceOther;
    })();
});
