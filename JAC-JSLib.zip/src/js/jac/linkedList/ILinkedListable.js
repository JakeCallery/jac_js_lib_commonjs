/**
 * Created with JetBrains PhpStorm.
 * User: Jake
 */

define([],
function(){
    return (function(){

	    /**
	     * @interface
	     */
	    var ILinkedListable = {};

	    ILinkedListable.linkedListNodeRef = {};
        
        //Return constructor
        return ILinkedListable;
    })();
});
